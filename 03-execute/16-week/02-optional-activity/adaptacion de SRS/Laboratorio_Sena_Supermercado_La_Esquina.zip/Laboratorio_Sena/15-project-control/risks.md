# risks

> Estado: 🔴 No aplica como registro de riesgos — información relacionada disponible en otra sección
> Última actualización: 2026-07-03

## Motivo

El SRS no incluye un registro formal de riesgos del proyecto (probabilidad, impacto, mitigación). Lo que sí incluye es una **Matriz de Priorización de Requisitos** (sección 16), que clasifica cada requisito por impacto y urgencia — un concepto distinto (gestión de requisitos, no gestión de riesgos). Esa matriz está documentada en [`04-requirements/functional.md`](../04-requirements/functional.md).

## Información que haría falta

- Identificación de riesgos del proyecto (técnicos, de alcance, de cronograma).
- Probabilidad e impacto de cada riesgo.
- Plan de mitigación.

Esta información no está documentada en el SRS actual.
