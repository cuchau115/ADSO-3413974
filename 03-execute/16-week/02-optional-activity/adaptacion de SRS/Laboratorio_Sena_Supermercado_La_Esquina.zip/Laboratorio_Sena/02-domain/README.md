# Dominio

> Estado: 🔴 Pendiente | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Contenido

Define el modelo de dominio, las entidades principales, reglas de negocio y eventos relevantes.

> **Diferencia con `06-data`:** esta sección describe el dominio en términos de negocio (entidades, invariantes, reglas, lenguaje ubicuo). No describe tablas, columnas ni esquemas de base de datos. Esos detalles de implementación van en [`06-data/`](../06-data/).

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [domain-map.md](./domain-map.md) | Mapa de dominio y contextos principales | 🟢 |
| [entities-and-rules.md](./entities-and-rules.md) | Entidades, invariantes y reglas de negocio | 🟡 |
| [domain-events.md](./domain-events.md) | Eventos de dominio y significado funcional | 🔴 |

## Nota sobre disponibilidad de información

El SRS del Supermercado "La Esquina" no define eventos de dominio (domain events) en ningún apartado. Por esta razón, [`domain-events.md`](./domain-events.md) no pudo completarse con contenido derivado del SRS; contiene únicamente la justificación de esta ausencia. Para poder documentar eventos de dominio haría falta especificar, para cada operación relevante (ej. venta registrada, stock agotado, cierre de caja confirmado), el evento generado, su disparador y los efectos que produce en otros módulos — información que el SRS no levanta.
