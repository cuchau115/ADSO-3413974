# Arquitectura

> Estado: 🔴 Pendiente | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Contenido

Describe la arquitectura del sistema, despliegue, decisiones técnicas y aspectos transversales.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [overview.md](./overview.md) | Vista general de arquitectura y componentes (limitado a lo declarado en el SRS) | 🟡 |
| [deployment.md](./deployment.md) | Topología de despliegue y ambientes (limitado a restricciones declaradas) | 🟡 |
| [cross-cutting.md](./cross-cutting.md) | Seguridad, logging, auditoría, errores y demás aspectos transversales | 🔴 No disponible en el SRS |
| [decisions/](./decisions/) | Registro de decisiones de arquitectura (ADR) | 🔴 No disponible en el SRS |
