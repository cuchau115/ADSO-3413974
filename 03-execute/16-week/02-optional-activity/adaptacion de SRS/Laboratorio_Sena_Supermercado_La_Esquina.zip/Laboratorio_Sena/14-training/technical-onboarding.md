# technical-onboarding

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS no contiene una guía de incorporación para integrantes técnicos del proyecto (no describe estructura del código, convenciones de desarrollo, ni proceso de onboarding técnico).

## Información que haría falta

- Estructura del proyecto/código.
- Convenciones de desarrollo.
- Pasos para que un nuevo integrante técnico configure su entorno y comience a contribuir.

Esta información no está documentada en el SRS actual.
