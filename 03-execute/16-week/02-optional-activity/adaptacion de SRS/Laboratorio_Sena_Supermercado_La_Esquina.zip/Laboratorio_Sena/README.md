# design-software-docs

Repositorio de documentación del proyecto **SRS — Supermercado "La Esquina"** (ADSO — SENA, Ficha 3413974).

> Este repositorio usa una plantilla de laboratorio originalmente rotulada para el proyecto "Horarios SENA". Su contenido se reorganizó a partir del único documento fuente disponible: `SRS_Supermercado_La_Esquina.docx` (Index 3, Mayo 2026). No se creó, infirió ni completó ninguna información que el SRS no contuviera; donde el SRS no aporta información, la carpeta correspondiente indica explícitamente esa ausencia y qué haría falta para completarla.

Este repositorio es la fuente de verdad documental del proyecto. Todo cambio debe pasar por rama, Pull Request y revisión; no se trabaja directamente sobre `dev`, `qa` ni `main`.

## Reglas rápidas

- Leer [CONTRIBUTING.md](./CONTRIBUTING.md) antes de agregar o mover documentos.
- Registrar cada archivo nuevo en el `README.md` de su sección.
- No publicar credenciales, tokens, llaves privadas, datos personales ni información sensible de infraestructura.
- Mantener fuente editable y exportación para cada diagrama.
- Usar `99-archive/` para preservar documentos deprecados; no eliminar historia sin acuerdo del equipo.

## Estructura

| Sección | Descripción | Estado |
|---------|-------------|--------|
| [00-governance](./00-governance/) | Reglas, convenciones y criterios del repo (contenido del laboratorio, no del SRS) | 🟡 |
| [01-context](./01-context/) | Contexto institucional, alcance y glosario | 🟢 |
| [02-domain](./02-domain/) | Módulos del sistema, entidades mencionadas y eventos de dominio | 🟡 |
| [03-product](./03-product/) | Visión de producto; roadmap y backlog no están en el SRS | 🟡 |
| [04-requirements](./04-requirements/) | Requisitos funcionales, no funcionales, casos de uso y trazabilidad | 🟢 |
| [05-architecture](./05-architecture/) | Naturaleza de la solución y restricciones; sin ADRs ni diagramas de arquitectura | 🟡 |
| [06-data](./06-data/) | Campos mencionados en el SRS; sin modelo de datos formal | 🟡 |
| [07-api](./07-api/) | El SRS excluye APIs del alcance del sistema | 🔴 No aplica |
| [08-uml](./08-uml/) | El SRS no contiene diagramas UML | 🔴 No aplica |
| [09-microservices](./09-microservices/) | El SRS excluye microservicios del alcance del sistema | 🔴 No aplica |
| [10-devops](./10-devops/) | El SRS no documenta setup local, CI/CD ni ambientes | 🔴 No aplica |
| [11-quality](./11-quality/) | El SRS no documenta estrategia de testing ni code review | 🔴 No aplica |
| [12-ux-ui](./12-ux-ui/) | Pantallas descritas textualmente en el SRS; sin design system ni wireframes | 🟡 |
| [13-operations](./13-operations/) | El SRS no documenta observabilidad, incidentes ni backups formales | 🔴 No aplica |
| [14-training](./14-training/) | El SRS no incluye manuales; ver Casos de Uso relacionados | 🔴 No aplica |
| [15-project-control](./15-project-control/) | Dependencias documentadas; sin backlog técnico, riesgos ni preguntas abiertas | 🟡 |
| [99-archive](./99-archive/) | Decisiones y documentos deprecados | 🟡 |

## Estado de íconos
- 🔴 Pendiente / No aplica (información no disponible en el SRS) — 🟡 En progreso / Parcial — 🟢 Estable
- ⚫ Deprecado

## Documentos de gobierno

- [Guía de contribución](./CONTRIBUTING.md)
- [Reglas de documentación](./00-governance/documentation-rules.md)
- [Convenciones de Git](./00-governance/git-conventions.md)
- [Documentación de microservicios](./00-governance/microservices-documentation.md)
- [Seguridad documental](./00-governance/security-rules.md)
- [Definition of Ready](./00-governance/definition-of-ready.md)
- [Definition of Done](./00-governance/definition-of-done.md)
- [CHANGELOG](./CHANGELOG.md)
- [CODEOWNERS](./.github/CODEOWNERS)
