# communication-patterns

> Estado: 🔴 No aplica — el SRS excluye microservicios del alcance
> Última actualización: 2026-07-03

## Motivo

El sistema no está compuesto por microservicios (ver [`service-catalog.md`](./service-catalog.md)). El SRS indica en la sección 12.3 que "el sistema no requiere comunicación en red con servidores externos ni integración con servicios de terceros" y que toda la información se almacena y procesa localmente. No existen, por tanto, patrones de comunicación entre servicios que documentar.
