# navigation-map

> Estado: 🟡 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", sección 12.1 (Interfaces de Usuario).

## Alcance de este documento

El SRS no incluye un mapa de navegación formal (jerarquía de pantallas, transiciones) ni wireframes visuales. Describe únicamente, en prosa y lista, las pantallas y elementos de interfaz que el sistema debe contemplar. Se transcriben aquí tal como aparecen en el documento.

## Pantallas y secciones descritas en el SRS

El sistema debe contar con una interfaz gráfica sencilla e intuitiva, diseñada para usuarios con conocimientos básicos en tecnología:

- Pantalla de inicio de sesión con campos de usuario y contraseña.
- Menú principal con acceso directo a los cinco módulos del sistema (Ventas, Inventario, Caja, Reportes, Proveedores).
- Formularios simples para el registro y consulta de ventas, productos y proveedores.
- Tabla de productos con buscador por nombre o categoría.
- Sección de alertas visibles para productos con bajo nivel de stock.
- Sección de reportes con opciones de filtro por fecha (diario, semanal, mensual).
- Sección de cierre de caja con resumen del día y opción de confirmar cierre.
- Mensajes de confirmación y error en lenguaje claro y sencillo.

> Estos elementos no se documentan en [`04-requirements/`](../04-requirements/) para evitar duplicación, ya que corresponden específicamente a la especificación de interfaz de usuario (sección 12.1 del SRS), distinta de los requisitos funcionales (sección 13).
