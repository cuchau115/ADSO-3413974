# authentication

> Estado: 🔴 No aplica como autenticación de API — información relacionada disponible en otra sección
> Última actualización: 2026-07-03

## Motivo

El SRS no define un mecanismo de autenticación de API (no hay APIs contempladas; ver [`guidelines.md`](./guidelines.md)). Lo que sí define es un control de acceso **a nivel de aplicación**: inicio de sesión con usuario y contraseña, con dos roles (Administrador y Cajero), documentado como requisito no funcional RNF03 en [`04-requirements/non-functional.md`](../04-requirements/non-functional.md).

## Información que haría falta

- Mecanismo de autenticación para una eventual API (tokens, OAuth, API keys).
- Política de expiración y renovación de credenciales de API.

Esta información no está documentada en el SRS actual.
