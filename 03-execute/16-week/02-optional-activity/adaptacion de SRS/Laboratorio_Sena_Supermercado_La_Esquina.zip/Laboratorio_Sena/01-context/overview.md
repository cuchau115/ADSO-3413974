# Overview

> Estado: 🟢 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina" (Mayo 2026), secciones 1, 2, 3, 4, 5, 6 y 11.

## Contexto institucional

Documento elaborado en el marco del programa Tecnólogo en Análisis y Desarrollo de Software (ADSO) del Servicio Nacional de Aprendizaje (SENA), Ficha 3413974, Neiva, Huila. Corresponde al Index 3 del proyecto académico, continuación directa del levantamiento de información (Index 1) y del análisis de datos (Index 2).

Elaborado por: Juan David Gómez Martínez (Analista/Desarrollador). Instructor: Jesús Ariel González Bonilla.

## Problema

El Supermercado "La Esquina" es un establecimiento local dedicado a la venta de productos de consumo diario (alimentos, bebidas, artículos de aseo y elementos básicos del hogar). Todas sus operaciones se realizan de forma manual, lo que genera los siguientes problemas identificados durante el levantamiento de información (Index 1) mediante entrevistas, encuestas, observación directa y revisión documental:

- El registro de ventas se realiza en cuadernos físicos, con alto riesgo de errores de cálculo y pérdida de información.
- El inventario no se actualiza de forma constante, lo que impide conocer en tiempo real la disponibilidad de productos.
- No existe un mecanismo de alerta cuando los productos están próximos a agotarse.
- La búsqueda de precios es lenta y depende de listas físicas desactualizadas.
- El cierre de caja diario consume tiempo excesivo por la naturaleza manual del proceso.
- No existen reportes organizados de ventas ni de ganancias, lo que dificulta la toma de decisiones.
- La gestión de proveedores se realiza sin seguimiento, sin fechas ni control de pedidos.
- Los documentos físicos están desorganizados, mezclados y sin clasificación.

Estas problemáticas generan pérdidas de tiempo, errores frecuentes y dificultades para el dueño del negocio, Don Carlos, al momento de tomar decisiones informadas.

## Propósito del documento

- Describir con claridad las funcionalidades que el sistema debe cumplir.
- Servir como guía de referencia durante el desarrollo del software.
- Garantizar la trazabilidad entre los hallazgos del levantamiento de información y los requisitos definidos.
- Facilitar la comprensión del sistema por parte del cliente, el desarrollador y el instructor evaluador.

Dirigido principalmente al estudiante desarrollador, al instructor del programa y al dueño del negocio (Don Carlos) como cliente del proyecto.

## Justificación

- El 100% de los participantes del levantamiento de información confirmó que utiliza registros manuales para sus procesos.
- El 73% (11 de 15 registros) indicó necesitar reportes organizados que actualmente no existen.
- Los problemas de mayor frecuencia identificados fueron: inventario desactualizado, errores en ventas y falta de reportes, todos calificados con prioridad alta.
- Citas textuales recolectadas evidencian necesidades reales y urgentes: dificultad para saber cuándo se agotan los productos, errores frecuentes al sumar y demoras en el cierre de caja.

## Objetivo general

Desarrollar un sistema de gestión básico para el Supermercado "La Esquina" que permita automatizar los procesos de registro de ventas, control de inventario, gestión de caja y generación de reportes simples, con el fin de reducir errores, optimizar el tiempo operativo y mejorar el control general del negocio.

## Objetivos específicos

1. Registrar ventas de forma rápida y automática, calculando totales y cambios sin intervención manual.
2. Mantener actualizado el inventario de productos en tiempo real después de cada venta o entrada de mercancía.
3. Generar alertas cuando un producto tenga bajo nivel de stock o esté agotado.
4. Permitir la consulta rápida de precios de productos por nombre o categoría.
5. Facilitar el proceso de cierre de caja diario de forma automática.
6. Generar reportes simples de ventas e inventario para apoyar la toma de decisiones.
7. Registrar y organizar la información básica de proveedores y pedidos.
8. Controlar el acceso al sistema mediante autenticación básica de usuarios (administrador y cajero).

## Personal involucrado

| Actor | Rol en el sistema | Responsabilidades principales |
|---|---|---|
| Juan David Gómez Martínez | Analista / Desarrollador | Levantamiento de información, análisis de requisitos, diseño y desarrollo del sistema. |
| Jesús Ariel González Bonilla | Instructor / Evaluador | Orientación académica, revisión y evaluación del proyecto. |
| Don Carlos (Dueño) | Cliente / Usuario Administrador | Propietario del negocio. Gestiona inventario, proveedores, reportes y configuraciones del sistema. |
| Cajero/a del negocio | Usuario Cajero | Registra ventas, genera comprobantes y realiza el cierre de caja diario. |

## Resumen del sistema

El sistema es una solución de software básica diseñada para digitalizar y automatizar los procesos operativos más críticos del negocio. Está organizado en cinco módulos principales: Ventas, Inventario, Caja, Reportes y Proveedores. El acceso se controla mediante autenticación básica con dos roles: Administrador (Don Carlos) y Cajero, sin que esto constituya un módulo independiente. La solución reemplaza los registros manuales en cuadernos físicos por un sistema digital.

## Referencias

- IEEE Std 830-1998. IEEE Recommended Practice for Software Requirements Specifications.
- ISO/IEC/IEEE 29148:2018. Systems and software engineering — Life cycle processes — Requirements engineering.
- Documentos del Index 1: Entrevista estructurada, Encuesta, Observación directa, Revisión documental, Informe de hallazgos y reflexión, Lista de documentos revisados.
- Documentos del Index 2: Análisis de datos — Supermercado La Esquina (Excel con hojas: Datos_Recolectados, Organizacion_Datos, Categorizacion, Tablas_Frecuencia, Estadisticas_Basicas, Hallazgos, Prioridad_Problemas, Requisitos_Preliminares, Relacion_Hallazgos_Requisitos, Analisis_Cualitativo).
- Documento SRS previo (versión borrador): Documento_SRS.docx — utilizado como base de continuidad para el Index 3.

> Nota: este repositorio de laboratorio fue originalmente plantillado para el proyecto "Horarios SENA". El contenido anterior se reemplaza aquí por la información real del SRS del Supermercado "La Esquina", único documento fuente disponible.
