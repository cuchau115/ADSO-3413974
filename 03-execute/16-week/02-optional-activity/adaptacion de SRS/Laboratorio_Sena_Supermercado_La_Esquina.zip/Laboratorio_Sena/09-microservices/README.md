# Microservicios

> Estado: 🔴 Pendiente | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Contenido

Centraliza el catálogo de microservicios, patrones de comunicación y documentación por servicio.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [service-catalog.md](./service-catalog.md) | Inventario de servicios, owners, repos y estado documental | 🔴 El SRS excluye microservicios del alcance |
| [communication-patterns.md](./communication-patterns.md) | Patrones síncronos, asíncronos y resiliencia | 🔴 El SRS excluye microservicios del alcance |
| [_template/](./_template/) | Plantilla para documentar un servicio nuevo; no representa un microservicio real | 🟡 Plantilla del laboratorio, no se completa |
| [services/](./services/) | Documentación específica por microservicio | 🔴 El SRS excluye microservicios del alcance |
