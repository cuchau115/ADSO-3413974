# dependencies

> Estado: 🟢 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", sección 12.3 (Interfaces de Comunicación) y sección 7.2 (Alcance).

## Dependencias externas

El SRS declara explícitamente que **el sistema no depende de integraciones externas**:

> "El sistema no requiere comunicación en red con servidores externos ni integración con servicios de terceros. Toda la información se almacena y procesa localmente. No se contemplan interfaces de comunicación externas en este alcance." (sección 12.3)

Adicionalmente, el alcance (sección 7.2) excluye de forma explícita:

- Integración con pasarelas de pago, bancos o billeteras digitales.
- Facturación electrónica ni integración con la DIAN.
- Integración con plataformas digitales externas (e-commerce).

## Dependencias internas

El SRS no detalla dependencias internas entre módulos más allá de lo ya expresado en los flujos de los Casos de Uso (por ejemplo, el registro de una venta actualiza automáticamente el inventario — ver [`04-requirements/user-stories.md`](../04-requirements/user-stories.md), CU-01). No se documentan dependencias adicionales entre módulos, componentes o equipos.
