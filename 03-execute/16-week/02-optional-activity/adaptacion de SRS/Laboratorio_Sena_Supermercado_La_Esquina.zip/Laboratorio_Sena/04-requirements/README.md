# Requisitos

> Estado: 🟢 Completado a partir del SRS | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974

## Contenido

Centraliza requisitos funcionales, no funcionales, casos de uso (equivalente disponible en el SRS a las historias de usuario) y trazabilidad, tomados del SRS — Supermercado "La Esquina".

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [functional.md](./functional.md) | Requisitos funcionales del sistema (RF01–RF18) y matriz de priorización | 🟢 |
| [non-functional.md](./non-functional.md) | Requisitos de calidad, seguridad, rendimiento y operación (RNF01–RNF06) | 🟢 |
| [user-stories.md](./user-stories.md) | Casos de Uso (CU-01 a CU-04); el SRS no define historias de usuario en formato "Como/quiero/para" | 🟡 |
| [traceability-matrix.md](./traceability-matrix.md) | Trazabilidad Hallazgos → Requisitos | 🟢 |
