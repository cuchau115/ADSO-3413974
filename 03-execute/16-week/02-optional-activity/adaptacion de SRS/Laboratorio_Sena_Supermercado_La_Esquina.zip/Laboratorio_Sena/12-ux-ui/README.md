# UX/UI

> Estado: 🔴 Pendiente | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Contenido

Documenta sistema de diseño, navegación y wireframes del producto.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [design-system.md](./design-system.md) | Tokens, componentes, patrones visuales y reglas UX/UI | 🔴 No disponible en el SRS |
| [navigation-map.md](./navigation-map.md) | Mapa de navegación y jerarquía de pantallas (pantallas descritas textualmente en el SRS) | 🟡 |
| [wireframes.md](./wireframes.md) | Wireframes y referencias de interacción | 🔴 No disponible en el SRS |
