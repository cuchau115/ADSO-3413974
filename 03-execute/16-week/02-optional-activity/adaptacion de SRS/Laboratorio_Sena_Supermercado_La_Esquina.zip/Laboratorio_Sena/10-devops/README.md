# DevOps

> Estado: 🔴 Pendiente | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Contenido

Documenta instalación local, CI/CD y ambientes del proyecto.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [local-setup.md](./local-setup.md) | Preparación del entorno local de desarrollo | 🔴 No disponible en el SRS |
| [ci-cd.md](./ci-cd.md) | Pipelines, despliegues y controles de calidad automatizados | 🔴 No disponible en el SRS |
| [environments.md](./environments.md) | Ambientes, propósito y reglas de uso | 🔴 No disponible en el SRS |
