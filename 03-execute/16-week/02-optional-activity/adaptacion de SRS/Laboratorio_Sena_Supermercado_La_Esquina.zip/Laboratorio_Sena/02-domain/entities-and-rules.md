# entities-and-rules

> Estado: 🟡 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", requisitos funcionales (sección 13).

## Nota de alcance

El SRS no incluye un modelo de dominio formal (entidades, invariantes y reglas de negocio documentadas como tal). La siguiente tabla reúne únicamente los conceptos y atributos que el documento menciona explícitamente al describir los requisitos funcionales. No se agregan invariantes, relaciones ni reglas adicionales que no estén escritas en el SRS.

## Conceptos mencionados en el SRS

| Concepto | Atributos/menciones en el SRS | Requisito(s) fuente |
|---|---|---|
| Producto | nombre, categoría, precio unitario, cantidad en stock | RF06, RF07, RF08, RF09, RF10 |
| Venta | productos vendidos, cantidades, valores, total, cambio | RF01, RF02, RF03, RF04 |
| Comprobante | detalle de productos, cantidades, precios y total de una venta | RF03 |
| Cierre de caja | resumen automático de ingresos del día | RF11, RF12 |
| Proveedor | nombre, contacto, productos que suministra | RF16, RF18 |
| Pedido (a proveedor) | fecha, productos solicitados, estado del pedido | RF17, RF18 |
| Usuario del sistema | rol (Administrador o Cajero), usuario y contraseña | RNF03 |

## Reglas mencionadas explícitamente

- El sistema debe calcular automáticamente el total de la venta y el cambio, sin intervención manual (RF02).
- El inventario debe actualizarse automáticamente después de cada venta o entrada de mercancía (RF07).
- Debe mostrarse una alerta cuando el stock de un producto alcance un nivel mínimo definido (RF10).
- Existen dos roles de acceso: Administrador (acceso completo) y Cajero (acceso a ventas y caja) (RNF03).

> No se documentan en el SRS invariantes adicionales (por ejemplo, reglas de cálculo de precios, políticas de descuento, o restricciones de stock negativo) más allá de lo listado arriba.
