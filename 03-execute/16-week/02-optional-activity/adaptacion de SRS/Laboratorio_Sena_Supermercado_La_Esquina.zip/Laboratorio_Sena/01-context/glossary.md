# Glosario

> Estado: 🟢 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", sección 9 (Definiciones, Acrónimos y Abreviaturas).

> Nota: la tabla original de esta plantilla (Ficha, Jornada, Horario, Instructor, Aprendiz) correspondía al proyecto "Horarios SENA" y no forma parte del SRS del Supermercado "La Esquina". Se reemplaza por el glosario real definido en el documento fuente.

| Término / Acrónimo | Definición |
|---|---|
| SRS | Software Requirements Specification — Especificación de Requisitos de Software. |
| IEEE | Institute of Electrical and Electronics Engineers. Organización que define estándares técnicos. |
| ADSO | Análisis y Desarrollo de Software. Programa tecnólogo del SENA. |
| SENA | Servicio Nacional de Aprendizaje. Institución de formación profesional colombiana. |
| RF | Requisito Funcional. Define qué debe hacer el sistema. |
| RNF | Requisito No Funcional. Define cómo debe comportarse el sistema. |
| RN | Requisito de Negocio. Define las necesidades estratégicas del cliente. |
| Stock | Cantidad de productos disponibles en el inventario del supermercado. |
| Cierre de caja | Proceso de contabilización de ingresos y egresos al finalizar la jornada laboral. |
| Módulo | Componente funcional independiente del sistema que agrupa funcionalidades relacionadas. |
| Comprobante | Documento simple generado por el sistema que resume una venta realizada. |
| CRUD | Create, Read, Update, Delete — operaciones básicas de gestión de datos. |
