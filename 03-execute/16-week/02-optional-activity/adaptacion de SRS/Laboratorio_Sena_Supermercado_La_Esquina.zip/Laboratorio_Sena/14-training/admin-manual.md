# admin-manual

> Estado: 🔴 No aplica como manual de administración — información relacionada disponible en otra sección
> Última actualización: 2026-07-03

## Motivo

El SRS no contiene un manual de administración. El contenido más cercano disponible son los Casos de Uso CU-02 (Gestionar Inventario) y CU-03 (Generar Reporte de Ventas), que describen las interacciones esperadas del Administrador (Don Carlos) con el sistema, documentados en [`04-requirements/user-stories.md`](../04-requirements/user-stories.md).

## Información que haría falta

- Procedimientos administrativos paso a paso (gestión de usuarios, configuración del sistema).
- Guías de resolución de problemas para el administrador.

Esta información no está documentada en el SRS actual.
