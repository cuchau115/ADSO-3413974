# cross-cutting

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" no documenta aspectos transversales de arquitectura como logging, auditoría, manejo estructurado de errores, o estrategia de seguridad a nivel de aplicación.

Lo único relacionado que sí está documentado son:

- El **control de acceso por roles** (Administrador/Cajero), definido como requisito no funcional RNF03 — ver [`04-requirements/non-functional.md`](../04-requirements/non-functional.md).
- Los **mensajes de confirmación y error en lenguaje claro**, mencionados como característica de la interfaz de usuario (sección 12.1) — ver [`12-ux-ui/README.md`](../12-ux-ui/README.md).

Estos dos puntos son requisitos de producto, no una definición arquitectónica de aspectos transversales (no especifican mecanismos de logging, niveles de auditoría, ni políticas de manejo de excepciones).

## Información que haría falta

- Estrategia de logging y niveles de severidad.
- Política de auditoría (qué se audita, quién, cuándo).
- Estrategia de manejo de errores a nivel de sistema (no solo de mensajes al usuario).
- Consideraciones de seguridad a nivel de aplicación (cifrado, gestión de contraseñas, etc.).

Esta información no está documentada en el SRS actual.
