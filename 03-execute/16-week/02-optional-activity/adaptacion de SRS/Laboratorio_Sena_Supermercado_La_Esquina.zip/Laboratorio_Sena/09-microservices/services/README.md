# services/

> Estado: 🔴 No aplica — el SRS excluye microservicios del alcance
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" especifica una única aplicación local (sección 7.1), no una arquitectura de microservicios (excluida explícitamente en la sección 7.2). Por lo tanto, no existe ningún microservicio individual que documentar en esta carpeta.

## Información que haría falta

Para poblar esta carpeta harían falta un rediseño del sistema bajo una arquitectura de microservicios y la definición de cada servicio (responsabilidad, contrato de API, modelo de datos propio) — decisión que el SRS no contempla y que excede el alcance definido por el documento fuente.
