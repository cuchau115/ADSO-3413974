# design-system

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" no define un sistema de diseño (paleta de colores, tipografía, tokens, componentes visuales reutilizables). Solo indica cualidades generales de la interfaz: debe ser "sencilla e intuitiva" y operable "sin capacitación técnica avanzada" (RNF01, ver [`04-requirements/non-functional.md`](../04-requirements/non-functional.md)).

## Información que haría falta

- Paleta de colores y tipografía.
- Componentes de interfaz reutilizables (botones, inputs, tablas).
- Reglas de espaciado, iconografía y estilo visual.

Esta información no está documentada en el SRS actual.
