# testing-strategy

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" no define una estrategia de pruebas (tipos de prueba, niveles, cobertura esperada, herramientas). Los "Flujos alternativos" descritos en los Casos de Uso (sección 15, ver [`04-requirements/user-stories.md`](../04-requirements/user-stories.md)) señalan condiciones de error a manejar, pero no constituyen una estrategia de pruebas.

## Información que haría falta

- Tipos de prueba a realizar (unitarias, integración, aceptación).
- Herramientas de testing.
- Criterios de cobertura y aceptación.

Esta información no está documentada en el SRS actual.
