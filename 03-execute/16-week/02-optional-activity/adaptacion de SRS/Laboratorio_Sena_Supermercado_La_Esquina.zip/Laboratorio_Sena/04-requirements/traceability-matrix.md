# traceability-matrix

> Estado: 🟢 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", sección 17 (Relación Hallazgos — Requisitos).

Esta tabla establece la trazabilidad directa entre los hallazgos identificados durante el levantamiento de información (Index 1) y los requisitos funcionales definidos en el SRS (sección 13, ver [`functional.md`](./functional.md)). Garantiza que cada requisito tiene una justificación real derivada del análisis del negocio.

| Hallazgo identificado | Necesidad del negocio | Requisito relacionado |
|---|---|---|
| Registro manual de ventas en cuadernos | Digitalizar y automatizar el registro de ventas | RF01, RF02, RF03 |
| Errores frecuentes al calcular totales y cambios | Cálculo automático sin intervención manual | RF02 |
| Inventario desactualizado y sin control | Actualización automática del inventario tras cada venta | RF07, RF08 |
| Productos agotados sin control ni aviso | Alertas automáticas de stock bajo | RF10 |
| Dificultad para consultar precios rápidamente | Búsqueda rápida de productos por nombre o categoría | RF05, RF08 |
| Desorden documental en facturas y registros físicos | Historial digital organizado de ventas y compras | RF04, RF12 |
| Cierre de caja lento y con posibles errores de cálculo | Cierre de caja automatizado con resumen del día | RF11, RF12 |
| Ausencia de reportes de ventas y ganancias | Generación de reportes simples por período | RF13, RF14, RF15 |
| Gestión desordenada de pedidos a proveedores | Registro y seguimiento básico de proveedores y pedidos | RF16, RF17, RF18 |
| Sin historial de compras organizado | Historial de ventas y cierres de caja consultable | RF04, RF12 |

> El SRS no incluye trazabilidad hacia decisiones de arquitectura ni hacia pruebas (ADRs, casos de prueba), ya que estos artefactos no están documentados en el SRS. Ver [`05-architecture/decisions/README.md`](../05-architecture/decisions/README.md) y [`11-quality/README.md`](../11-quality/README.md).
