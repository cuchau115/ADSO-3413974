# overview

> Estado: 🟡 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", secciones 7.1, 11 y 12.2.

## Alcance de este documento

El SRS no define una arquitectura de software formal (componentes, capas, patrones arquitectónicos, diagramas de componentes). La información disponible se limita a la naturaleza general de la solución y a las interfaces de software declaradas. Este archivo transcribe únicamente esa información; no propone una arquitectura.

## Naturaleza de la solución

El sistema está diseñado para funcionar como una **aplicación de escritorio o aplicación web básica de uso local**, apropiada para las capacidades técnicas y el tamaño del negocio. No contempla arquitecturas en la nube, microservicios ni sistemas distribuidos (fuera de alcance, sección 7.2).

## Organización funcional

El sistema está organizado en cinco módulos principales: Ventas, Inventario, Caja, Reportes y Proveedores (ver [`02-domain/domain-map.md`](../02-domain/domain-map.md)).

## Interfaces de software declaradas (sección 12.2)

- Motor de base de datos local (por ejemplo, SQLite o MySQL local) para el almacenamiento de la información.
- Sistema operativo Windows como entorno de ejecución principal.
- Navegador web estándar (en caso de implementación web básica local).

## Interfaces de comunicación (sección 12.3)

El sistema no requiere comunicación en red con servidores externos ni integración con servicios de terceros. Toda la información se almacena y procesa localmente. No se contemplan interfaces de comunicación externas en este alcance.

> El SRS no incluye diagramas de arquitectura, patrones de diseño, ni definición de capas (presentación/negocio/datos). Esa información no está disponible para completarse.
