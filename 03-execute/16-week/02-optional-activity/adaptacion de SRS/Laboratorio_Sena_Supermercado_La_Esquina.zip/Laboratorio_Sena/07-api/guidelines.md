# guidelines

> Estado: 🔴 No aplica — el SRS excluye explícitamente esta funcionalidad
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" declara explícitamente, en el alcance (sección 7.2) y en las interfaces de comunicación (sección 12.3), que el sistema **no requiere comunicación en red con servidores externos ni integración con servicios de terceros**, y que las arquitecturas en la nube, microservicios o sistemas distribuidos están fuera de alcance. Por lo tanto, el SRS no define ninguna API ni lineamientos de diseño de API.

## Información que haría falta

- Definición de si el sistema expondrá alguna API (actualmente el SRS indica que no).
- Convenciones de nombrado, versionado y formato de respuesta, si en el futuro se decide exponer una.

Esta información no está documentada en el SRS actual porque el sistema no contempla APIs.
