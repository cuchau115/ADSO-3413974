# user-stories

> Estado: 🟡 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", sección 15 (Casos de Uso Principales).

## Nota de fidelidad

El SRS **no** formula Historias de Usuario en formato "Como [rol] quiero [acción] para [beneficio]". El artefacto equivalente que sí documenta el SRS son los **Casos de Uso**, descritos con actor, precondiciones, flujo normal, flujo alternativo y postcondiciones. Se documentan aquí, en la carpeta más cercana de la estructura del laboratorio, sin reformular su contenido como historias de usuario.

## CU-01: Registrar Venta

- **Actor principal:** Cajero
- **Descripción:** El cajero registra los productos de una venta, el sistema calcula el total y el cambio, y genera un comprobante simple.
- **Precondiciones:** El cajero ha iniciado sesión. Los productos están registrados en el sistema.
- **Flujo normal:**
  1. El cajero selecciona la opción "Nueva Venta".
  2. Ingresa los productos (por nombre o código) y sus cantidades.
  3. El sistema muestra el precio de cada producto y el total acumulado.
  4. El cajero ingresa el valor recibido del cliente.
  5. El sistema calcula y muestra el cambio a entregar.
  6. El cajero confirma la venta.
  7. El sistema registra la venta y actualiza el inventario automáticamente.
  8. Se genera el comprobante de la venta.
- **Flujo alternativo:** Si un producto no está registrado, el sistema muestra un mensaje de error. Si el stock es insuficiente, el sistema alerta al cajero antes de confirmar.
- **Postcondiciones:** La venta queda registrada en el historial. El inventario se actualiza con las cantidades vendidas.
- **RF asociados:** RF01, RF02, RF03, RF04, RF07

## CU-02: Gestionar Inventario

- **Actor principal:** Administrador (Don Carlos)
- **Descripción:** El administrador registra, edita o consulta los productos del inventario, y verifica alertas de stock bajo.
- **Precondiciones:** El administrador ha iniciado sesión con su rol correspondiente.
- **Flujo normal:**
  1. El administrador accede al módulo de Inventario.
  2. Visualiza el listado actual de productos con su stock y precio.
  3. Selecciona una opción: agregar, editar o consultar producto.
  4. Completa la información requerida en el formulario.
  5. El sistema guarda los cambios y actualiza el inventario.
  6. El sistema muestra alertas si algún producto tiene stock bajo.
- **Flujo alternativo:** Si los datos del formulario están incompletos, el sistema no permite guardar y muestra el campo faltante. Si el producto ya existe, el sistema sugiere editar en lugar de duplicar.
- **Postcondiciones:** El inventario queda actualizado. Las alertas de stock bajo son visibles en el panel principal.
- **RF asociados:** RF06, RF07, RF08, RF09, RF10

## CU-03: Generar Reporte de Ventas

- **Actor principal:** Administrador (Don Carlos)
- **Descripción:** El administrador genera un reporte simple de ventas para un período de tiempo determinado.
- **Precondiciones:** Existen ventas registradas en el sistema. El administrador ha iniciado sesión.
- **Flujo normal:**
  1. El administrador accede al módulo de Reportes.
  2. Selecciona el tipo de reporte (ventas o inventario).
  3. Define el período de consulta (día, semana o mes).
  4. El sistema procesa la información y genera el reporte.
  5. El administrador visualiza el reporte con los datos del período.
- **Flujo alternativo:** Si no hay ventas en el período seleccionado, el sistema muestra un mensaje informativo. Si el rango de fechas es inválido, el sistema solicita corrección.
- **Postcondiciones:** El reporte se genera y puede ser consultado por el administrador.
- **RF asociados:** RF13, RF14, RF15

## CU-04: Realizar Cierre de Caja

- **Actor principal:** Cajero / Administrador
- **Descripción:** Al finalizar la jornada, el sistema genera automáticamente el resumen de ingresos del día y permite confirmar el cierre de caja.
- **Precondiciones:** El usuario ha iniciado sesión. Existen ventas registradas durante el día.
- **Flujo normal:**
  1. El usuario accede al módulo de Caja.
  2. Selecciona la opción "Cierre de Caja".
  3. El sistema muestra el resumen: total de ventas del día, número de transacciones y total en caja.
  4. El usuario revisa la información y confirma el cierre.
  5. El sistema registra el cierre y guarda el historial.
- **Flujo alternativo:** Si no hay ventas en el día, el sistema indica que no hay movimientos registrados. Si el usuario cancela, el cierre no se registra y puede intentarse nuevamente.
- **Postcondiciones:** El cierre de caja queda registrado en el historial. El sistema queda listo para el siguiente día de operación.
- **RF asociados:** RF11, RF12
