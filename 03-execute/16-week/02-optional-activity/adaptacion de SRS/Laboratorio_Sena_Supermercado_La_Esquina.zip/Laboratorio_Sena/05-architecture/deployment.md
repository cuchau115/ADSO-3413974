# deployment

> Estado: 🟡 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", secciones 7.1, 12.2 y 14.1.

## Alcance de este documento

El SRS no incluye una topología de despliegue (diagrama de nodos, ambientes de desarrollo/QA/producción, servidores). La información disponible se limita a las condiciones de ejecución declaradas como restricciones del sistema.

## Condiciones de ejecución declaradas

- El sistema debe funcionar en equipos de escritorio con sistema operativo Windows, disponibles en el negocio.
- No se requiere conexión a internet para el funcionamiento del sistema.
- El alcance del sistema se limita a un único establecimiento (sucursal única): no hay múltiples sedes ni sincronización entre sitios.
- El sistema funciona como aplicación de escritorio o aplicación web básica de uso local (sin servidor externo).

> El SRS no define ambientes (dev/test/prod), estrategia de despliegue, ni infraestructura de servidores. Ver nota de ausencia en [`10-devops/README.md`](../10-devops/README.md).
