# vision

> Estado: 🟢 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", secciones 3, 4, 5 y 11.

## Propuesta de valor

Un sistema básico de gestión permitirá automatizar los procesos más críticos del Supermercado "La Esquina" (ventas, inventario, caja, reportes y proveedores), reduciendo errores humanos, ahorrando tiempo operativo y mejorando la capacidad del dueño para tomar decisiones basadas en información organizada y accesible.

## Objetivo general del producto

Desarrollar un sistema de gestión básico para el Supermercado "La Esquina" que permita automatizar los procesos de registro de ventas, control de inventario, gestión de caja y generación de reportes simples, con el fin de reducir errores, optimizar el tiempo operativo y mejorar el control general del negocio.

## A quién sirve

- **Don Carlos (Dueño)** — Cliente / Usuario Administrador: gestiona inventario, proveedores, reportes y configuraciones del sistema.
- **Cajero/a del negocio** — Usuario Cajero: registra ventas, genera comprobantes y realiza el cierre de caja diario.

## Resultado esperado

El sistema propuesto transformará el modo en que el Supermercado "La Esquina" gestiona sus operaciones diarias: reemplazando cuadernos físicos por registros digitales, eliminando errores de cálculo manual, facilitando el control del inventario y permitiendo al dueño del negocio acceder a información organizada para tomar mejores decisiones.

> El SRS no incluye un roadmap de evolución del producto ni un backlog priorizado en formato de producto (épicas, sprints). Ver notas de ausencia en [`roadmap.md`](./roadmap.md) y [`product-backlog.md`](./product-backlog.md).
