# ci-cd

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS no menciona pipelines de integración continua, despliegue automatizado ni controles de calidad automatizados. El sistema se especifica como una aplicación local de alcance académico (sección 14.1), sin procesos de CI/CD descritos.

## Información que haría falta

- Herramienta de CI/CD a utilizar.
- Etapas del pipeline (build, test, deploy).
- Ambientes de destino y criterios de promoción.

Esta información no está documentada en el SRS actual.
