# environments

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS no define ambientes de desarrollo, pruebas o producción. El sistema se especifica como una única instalación local en el negocio (sucursal única, sin sincronización remota), sin distinción de ambientes.

## Información que haría falta

- Lista de ambientes (dev, qa, producción) y su propósito.
- Diferencias de configuración entre ambientes.

Esta información no está documentada en el SRS actual.
