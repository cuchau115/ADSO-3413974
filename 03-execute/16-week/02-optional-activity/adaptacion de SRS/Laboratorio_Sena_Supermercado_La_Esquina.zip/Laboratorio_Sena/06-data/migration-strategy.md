# migration-strategy

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" no documenta ninguna estrategia de migración de datos (no hay mención a migración desde los registros manuales en cuadernos hacia el sistema digital, ni a versionado de esquemas).

## Información que haría falta

- Plan de carga inicial de datos (por ejemplo, digitalización del inventario existente).
- Estrategia de versionado de esquema de base de datos.
- Procedimiento de rollback ante migraciones fallidas.

Esta información no está documentada en el SRS actual.
