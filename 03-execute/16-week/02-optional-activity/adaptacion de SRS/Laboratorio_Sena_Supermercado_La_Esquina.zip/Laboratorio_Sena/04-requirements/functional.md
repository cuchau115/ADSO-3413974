# functional

> Estado: 🟢 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", sección 13 (Requisitos Funcionales) y sección 16 (Matriz de Priorización).

Los requisitos funcionales definen las funcionalidades específicas que el sistema debe proveer. Todos se derivan directamente de los hallazgos identificados en el Index 1 y los análisis realizados en el Index 2.

## 13.1 Módulo de Ventas

| ID | Nombre | Descripción | Fuente | Prioridad |
|---|---|---|---|---|
| RF01 | Registro de ventas | El sistema debe permitir registrar cada venta realizada, indicando los productos vendidos, cantidades y valores. | Entrevista / Observación | Alta |
| RF02 | Cálculo automático | El sistema debe calcular automáticamente el total de la venta y el cambio a entregar al cliente, sin intervención manual. | Observación directa | Alta |
| RF03 | Generación de comprobante | El sistema debe generar un comprobante simple de cada venta con el detalle de los productos, cantidades, precios y total. | Encuesta | Alta |
| RF04 | Historial de ventas | El sistema debe guardar el historial de ventas realizadas y permitir su consulta por fecha. | Entrevista / Docs | Alta |
| RF05 | Consulta de precios | El sistema debe permitir consultar el precio de cualquier producto de forma rápida, por nombre o categoría. | Observación directa | Alta |

## 13.2 Módulo de Inventario

| ID | Nombre | Descripción | Fuente | Prioridad |
|---|---|---|---|---|
| RF06 | Registro de productos | El sistema debe permitir registrar nuevos productos con nombre, categoría, precio unitario y cantidad en stock. | Entrevista administrador | Alta |
| RF07 | Actualización de inventario | El sistema debe actualizar automáticamente el inventario después de cada venta o entrada de mercancía registrada. | Observación directa | Alta |
| RF08 | Consulta de inventario | El sistema debe permitir consultar el listado completo de productos, con su stock actual, precio y categoría. | Encuesta | Alta |
| RF09 | Edición de productos | El sistema debe permitir editar la información de un producto existente (nombre, precio, categoría, stock). | Observación directa | Media |
| RF10 | Alertas de stock bajo | El sistema debe mostrar una alerta o notificación cuando el stock de un producto alcance un nivel mínimo definido. | Encuesta / Observación | Alta |

## 13.3 Módulo de Caja

| ID | Nombre | Descripción | Fuente | Prioridad |
|---|---|---|---|---|
| RF11 | Cierre de caja | El sistema debe permitir realizar el cierre de caja al final de la jornada, generando un resumen automático de los ingresos del día. | Observación directa | Alta |
| RF12 | Historial de cierres | El sistema debe guardar el historial de cierres de caja anteriores y permitir su consulta. | Revisión documental | Media |

## 13.4 Módulo de Reportes

| ID | Nombre | Descripción | Fuente | Prioridad |
|---|---|---|---|---|
| RF13 | Reporte de ventas | El sistema debe generar un reporte simple de ventas con opción de filtrar por día, semana o mes. | Encuesta / Entrevista | Alta |
| RF14 | Reporte de inventario | El sistema debe generar un reporte del estado actual del inventario, mostrando productos disponibles, bajo stock y agotados. | Encuesta | Alta |
| RF15 | Reporte de productos vendidos | El sistema debe mostrar un listado de los productos más vendidos en un período determinado. | Entrevista administrador | Media |

## 13.5 Módulo de Proveedores

| ID | Nombre | Descripción | Fuente | Prioridad |
|---|---|---|---|---|
| RF16 | Registro de proveedores | El sistema debe permitir registrar la información básica de los proveedores: nombre, contacto y productos que suministran. | Revisión documental | Media |
| RF17 | Registro de pedidos | El sistema debe permitir registrar los pedidos realizados a proveedores, indicando fecha, productos solicitados y estado del pedido. | Revisión documental | Media |
| RF18 | Consulta de proveedores | El sistema debe permitir consultar la lista de proveedores registrados y sus pedidos asociados. | Revisión documental | Media |

## Matriz de priorización de requisitos (RF y RNF)

Organiza todos los requisitos según su impacto en el negocio y urgencia de implementación, fundamentada en la frecuencia de mención durante el levantamiento de información y los hallazgos del Index 2. Los RNF referenciados se detallan en [`non-functional.md`](./non-functional.md).

| ID | Requisito | Impacto | Urgencia | Prioridad |
|---|---|---|---|---|
| RF01 | Registrar ventas | Alto | Alto | Alta |
| RF02 | Cálculo automático de totales y cambios | Alto | Alto | Alta |
| RF03 | Generación de comprobante de venta | Alto | Alto | Alta |
| RF04 | Historial de ventas | Alto | Medio | Alta |
| RF05 | Consulta de precios | Alto | Alto | Alta |
| RF06 | Registro de productos | Alto | Alto | Alta |
| RF07 | Actualización automática de inventario | Alto | Alto | Alta |
| RF08 | Consulta de inventario | Alto | Alto | Alta |
| RF09 | Edición de productos | Medio | Medio | Media |
| RF10 | Alertas de stock bajo | Alto | Alto | Alta |
| RF11 | Cierre de caja automatizado | Alto | Alto | Alta |
| RF12 | Historial de cierres de caja | Medio | Medio | Media |
| RF13 | Reporte de ventas | Alto | Medio | Alta |
| RF14 | Reporte de inventario | Alto | Medio | Alta |
| RF15 | Reporte de productos más vendidos | Medio | Bajo | Media |
| RF16 | Registro de proveedores | Medio | Medio | Media |
| RF17 | Registro de pedidos a proveedores | Medio | Bajo | Media |
| RF18 | Consulta de proveedores | Medio | Bajo | Media |
| RNF01 | Usabilidad e interfaz intuitiva | Alto | Alto | Alta |
| RNF02 | Rendimiento básico | Medio | Medio | Media |
| RNF03 | Control de acceso (roles básicos) | Alto | Alto | Alta |
| RNF04 | Facilidad de aprendizaje | Alto | Medio | Alta |
| RNF05 | Confiabilidad básica de datos | Medio | Medio | Media |

> Nota de fidelidad: el SRS no incluye a RNF06 (Mantenibilidad) dentro de esta matriz de priorización; la tabla se reproduce tal como aparece en el documento fuente, sin agregar la fila faltante.
