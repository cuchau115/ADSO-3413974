# Alcance

> Estado: 🟢 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", sección 7 (Alcance del Sistema) y sección 14.1 (Restricciones del sistema).

## En alcance

El sistema contempla los siguientes módulos funcionales:

- **Módulo de Ventas**: registro de ventas, cálculo de totales y cambios, generación de comprobantes simples.
- **Módulo de Inventario**: registro, consulta, actualización y control de productos; alertas de stock bajo.
- **Módulo de Caja**: cierre de caja diario automatizado, historial de ingresos del día.
- **Módulo de Reportes**: generación de reportes simples de ventas e inventario por periodos.
- **Módulo de Proveedores**: registro básico de proveedores y control de pedidos.
- **Control de acceso básico**: inicio de sesión con roles (administrador y cajero), sin módulo independiente de usuarios.

El sistema está diseñado para funcionar como una aplicación de escritorio o aplicación web básica de uso local, apropiada para las capacidades técnicas y el tamaño del negocio.

## Fuera de alcance

- Venta en línea (e-commerce) ni integración con plataformas digitales externas.
- Integración con pasarelas de pago, bancos o billeteras digitales.
- Facturación electrónica ni integración con la DIAN.
- Aplicación móvil para clientes.
- Arquitecturas en la nube, microservicios o sistemas distribuidos.
- Módulos de inteligencia de negocios (BI), dashboards avanzados o análisis de datos empresarial.
- Gestión multiempresa o soporte para múltiples sucursales.

## Supuestos

El SRS no documenta explícitamente una sección de "supuestos" del proyecto. No se completa este campo para evitar introducir información no declarada en el documento fuente.

## Restricciones

- El sistema debe funcionar en equipos de escritorio con sistema operativo Windows, disponibles en el negocio.
- No se requiere conexión a internet para el funcionamiento del sistema.
- El sistema no debe manejar pagos digitales, integraciones bancarias ni facturación electrónica.
- El alcance del sistema se limita a un único establecimiento (sucursal única).
- El desarrollo está sujeto al tiempo y alcance académico del programa ADSO — SENA.
