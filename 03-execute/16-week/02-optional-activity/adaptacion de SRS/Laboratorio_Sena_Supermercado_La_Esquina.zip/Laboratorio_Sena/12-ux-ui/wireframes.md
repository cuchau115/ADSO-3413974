# wireframes

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS no incluye wireframes ni bocetos visuales de pantallas (se confirmó que el documento no contiene imágenes embebidas). La descripción textual de las pantallas y elementos de interfaz disponible en el SRS se documenta en [`navigation-map.md`](./navigation-map.md).

## Información que haría falta

- Bocetos o mockups de cada pantalla (login, menú principal, ventas, inventario, caja, reportes, proveedores).
- Disposición de los elementos en cada pantalla.

Esta información no está documentada en el SRS actual.
