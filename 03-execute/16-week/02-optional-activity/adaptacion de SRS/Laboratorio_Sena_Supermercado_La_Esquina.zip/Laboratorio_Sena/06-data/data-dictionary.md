# data-dictionary

> Estado: 🟡 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", sección 13 (Requisitos Funcionales).

## Alcance de este documento

El SRS no presenta un diccionario de datos formal (con tipos de dato, longitudes, obligatoriedad o llaves). La siguiente tabla reúne únicamente los campos/atributos que el SRS menciona explícitamente al describir los requisitos funcionales de cada concepto. No se agregan tipos de dato, restricciones ni formatos que el documento no especifica.

| Concepto | Campos mencionados en el SRS | Requisito fuente |
|---|---|---|
| Producto | nombre, categoría, precio unitario, cantidad en stock | RF06 |
| Venta | productos vendidos, cantidades, valores | RF01 |
| Comprobante de venta | productos, cantidades, precios, total | RF03 |
| Cierre de caja | total de ventas del día, número de transacciones, total en caja | CU-04 (ver [`04-requirements/user-stories.md`](../04-requirements/user-stories.md)) |
| Proveedor | nombre, contacto, productos que suministra | RF16 |
| Pedido a proveedor | fecha, productos solicitados, estado del pedido | RF17 |

> El SRS no especifica tipos de dato, longitudes máximas, valores por defecto, ni si los campos son obligatorios u opcionales.
