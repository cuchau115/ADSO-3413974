# open-questions

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS no documenta preguntas abiertas o puntos pendientes de decisión. El documento se presenta como una especificación cerrada y validada para la etapa de Index 3 del proyecto académico.

## Información que haría falta

- Puntos que el equipo del proyecto identifique como pendientes de aclarar con el cliente (Don Carlos) o el instructor.

Esta información no está documentada en el SRS actual.
