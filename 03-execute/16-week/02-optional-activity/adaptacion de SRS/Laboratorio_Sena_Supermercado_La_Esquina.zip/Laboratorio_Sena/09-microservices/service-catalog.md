# service-catalog

> Estado: 🔴 No aplica — el SRS excluye microservicios del alcance
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" excluye explícitamente, en la sección 7.2 (Lo que el sistema NO incluye), las "Arquitecturas en la nube, microservicios o sistemas distribuidos". El sistema se especifica como una única aplicación de escritorio o web básica de uso local (sección 7.1). No existen microservicios que catalogar.

## Información que haría falta

Un catálogo de microservicios requeriría que el sistema estuviera diseñado bajo esa arquitectura, lo cual el SRS descarta explícitamente para este proyecto.
