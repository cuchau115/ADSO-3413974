# user-manual

> Estado: 🔴 No aplica como manual de usuario — información relacionada disponible en otra sección
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" no es un manual de usuario: no contiene instrucciones paso a paso orientadas al usuario final, capturas de pantalla, ni preguntas frecuentes. El contenido más cercano disponible son los **Casos de Uso** (CU-01 Registrar Venta, CU-04 Realizar Cierre de Caja), que describen el flujo esperado de interacción del Cajero con el sistema, documentados en [`04-requirements/user-stories.md`](../04-requirements/user-stories.md).

## Información que haría falta

- Instrucciones operativas paso a paso dirigidas al usuario final (capturas, ejemplos).
- Preguntas frecuentes y solución de problemas comunes.

Esta información no está documentada en el SRS actual.
