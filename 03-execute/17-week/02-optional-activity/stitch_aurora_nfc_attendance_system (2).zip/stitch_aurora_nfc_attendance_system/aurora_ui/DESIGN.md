---
name: Aurora UI
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fe'
  surface-container: '#ededf8'
  surface-container-high: '#e7e7f2'
  surface-container-highest: '#e2e1ed'
  on-surface: '#191b23'
  on-surface-variant: '#434654'
  inverse-surface: '#2e3038'
  inverse-on-surface: '#f0f0fb'
  outline: '#737686'
  outline-variant: '#c3c5d7'
  surface-tint: '#1a53d6'
  primary: '#1550d3'
  on-primary: '#ffffff'
  primary-container: '#3c6bed'
  on-primary-container: '#fffbff'
  inverse-primary: '#b5c4ff'
  secondary: '#5f3bdc'
  on-secondary: '#ffffff'
  secondary-container: '#7858f6'
  on-secondary-container: '#fffbff'
  tertiary: '#924700'
  on-tertiary: '#ffffff'
  tertiary-container: '#b75b00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b5c4ff'
  on-primary-fixed: '#00164d'
  on-primary-fixed-variant: '#003cad'
  secondary-fixed: '#e6deff'
  secondary-fixed-dim: '#cabeff'
  on-secondary-fixed: '#1d0061'
  on-secondary-fixed-variant: '#491ac6'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb786'
  on-tertiary-fixed: '#311300'
  on-tertiary-fixed-variant: '#723600'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e2e1ed'
  success: '#22C55E'
  warning: '#F59E0B'
  danger: '#EF4444'
  bg-aurora-blue: rgba(79, 124, 255, 0.05)
  bg-aurora-purple: rgba(122, 90, 248, 0.05)
  glass-surface: rgba(255, 255, 255, 0.7)
  glass-border: rgba(255, 255, 255, 0.4)
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  title-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  mono-data:
    fontFamily: Courier Prime
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.4'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is a premium, high-performance SaaS aesthetic tailored for the educational and enterprise sectors. It balances professional utility with a "future-forward" atmosphere, using **Glassmorphism** as its foundational style.

The brand personality is **Precise, Sophisticated, and Fluid**. It targets instructors and administrators who require a tool that feels more like a modern developer utility (similar to Vercel or Linear) than a legacy academic portal. 

Visual principles:
- **Depth through Translucency:** Interfaces use multi-layered glass surfaces to maintain context.
- **Luminous Interaction:** Elements feel "charged" with light, utilizing vibrant blues and purples to guide the eye.
- **Soft Precision:** High-radius corners (20px) provide a welcoming, tactile feel, while strict alignment and clean typography maintain professional authority.

## Colors
This design system operates primarily in a **Light Mode** that utilizes high-transparency layers. 

### Palette Logic
- **Primary (Electric Blue):** Used for action-oriented elements, active states, and successful NFC pings.
- **Secondary (Royal Purple):** Used for analytical data, instructor-specific controls, and decorative gradients.
- **Background Strategy:** Surfaces are not solid white. They use a "Soft White" base (#F9FAFB) layered with two large, low-opacity mesh gradients in the corners (top-left Blue, bottom-right Purple) to create the "Aurora" effect.
- **Glass Effects:** Surfaces use `glass-surface` with a `backdrop-filter: blur(12px)`. Borders must be a semi-transparent white to simulate the edge of the glass.

## Typography
The system relies on **Inter** to deliver a neutral, highly readable experience that doesn't compete with the vibrant glass visuals. 

- **Display & Headlines:** Use tight letter spacing and heavy weights to create a sense of importance.
- **Body Text:** Uses a slightly increased line-height (1.6) to ensure clarity during long attendance reviews.
- **Data Tables:** For NFC UIDs or time-stamps, use a monospaced font like **Courier Prime** to ensure character alignment and a "technical" feel.

## Layout & Spacing
The layout follows a **Fixed Grid** model for desktop to maintain the integrity of the glass card compositions, switching to a **Fluid Grid** for mobile NFC scanning views.

- **Desktop:** 12-column grid, 1200px max-width, 24px gutters. Content is housed in "Glass Containers" that typically span 4, 8, or 12 columns.
- **Mobile:** Single column with 16px side margins. The NFC "Tap Zone" should always be centered vertically in the viewport.
- **Rhythm:** Use a strict 8px base unit for all internal component padding and margins.

## Elevation & Depth
Depth in this design system is achieved through **Backdrop Blurs** and **Tonal Stacking** rather than traditional black shadows.

1.  **Level 0 (Base):** Soft white with mesh aurora gradients.
2.  **Level 1 (Cards):** Glass surface (70% opacity white) + 12px blur + 1px `glass-border`.
3.  **Level 2 (Floating/Modals):** Glass surface (80% opacity white) + 20px blur + a soft, tinted drop shadow using the primary color at 10% opacity (`0px 10px 30px rgba(79, 124, 255, 0.1)`).
4.  **Level 3 (Popovers):** Solid white with a crisp 1px neutral border for maximum legibility.

## Shapes
The shape language is defined by the **20px (1.25rem)** standard.

- **Standard Cards/Containers:** 20px radius.
- **Buttons/Inputs:** 12px radius for a slightly more compact, functional look.
- **Status Badges:** Fully rounded (pill) to distinguish them from interactive buttons.
- **NFC Visualizer:** Circular concentric rings to suggest the wireless field.

## Components

### Glass Cards
The primary container. Must have a `backdrop-filter: blur(12px)`, a `1px` stroke using `glass-border`, and a slight inner glow.

### Translucent Buttons
- **Primary:** Gradient fill (#4F7CFF to #7A5AF8) with 90% opacity and white text.
- **Secondary:** Glass background with a 1px border colored by the primary blue.
- **Ghost:** No background, primary color text, appears on hover.

### Modern Data Tables
Rows should not have borders. Use a alternating glass-tint background for zebra-striping (2% opacity white). Headers should be in `label-sm` with 40% opacity.

### Status Badges
Pill-shaped with a 10% opacity background of the status color (Success, Warning, Danger) and 100% opacity text. Add a small 4px solid dot next to the text for additional visual signaling.

### NFC Scanner View
A dedicated full-screen or modal component. It features a centered animated pulse (primary blue) and a large `headline-lg` instruction text. Upon success, the glass card should flash with a `success` colored inner-border.

### Input Fields
Soft white background (90% opacity), 12px rounded corners, and a subtle inner shadow. On focus, the border transitions to the Electric Blue with a soft glow effect.