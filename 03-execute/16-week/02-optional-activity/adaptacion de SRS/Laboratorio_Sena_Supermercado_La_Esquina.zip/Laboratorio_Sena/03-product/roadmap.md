# roadmap

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" no define hitos, fases de entrega ni una evolución planificada del producto en el tiempo. El documento se limita a especificar requisitos funcionales y no funcionales para una única versión del sistema.

## Información que haría falta

- Fases o iteraciones de desarrollo planeadas.
- Fechas o hitos de entrega.
- Criterios de qué se entrega en cada fase.

Esta información no está documentada en el SRS actual.
