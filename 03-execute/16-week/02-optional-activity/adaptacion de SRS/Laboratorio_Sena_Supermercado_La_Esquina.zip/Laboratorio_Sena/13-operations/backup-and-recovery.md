# backup-and-recovery

> Estado: 🔴 No aplica como plan de backup y recuperación — información relacionada disponible
> Última actualización: 2026-07-03

## Motivo

El SRS no define un plan formal de backups (frecuencia, RPO/RTO, pruebas de restauración). Lo único relacionado documentado es el requisito no funcional **RNF05 — Confiabilidad básica**: "El sistema debe guardar la información de ventas e inventario de manera que no se pierda ante un cierre inesperado del programa" (ver [`04-requirements/non-functional.md`](../04-requirements/non-functional.md)). Este requisito habla de resiliencia ante un cierre inesperado de la aplicación, no de una estrategia de copias de seguridad periódicas.

## Información que haría falta

- Frecuencia y mecanismo de backups.
- Objetivos de RPO/RTO.
- Procedimiento y pruebas de restauración.

Esta información no está documentada en el SRS actual.
