# local-setup

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" no describe pasos de instalación ni configuración de entorno de desarrollo (herramientas, versiones, dependencias, gestor de paquetes). Únicamente declara, como restricción del sistema y como interfaz de software, que el sistema debe ejecutarse en equipos Windows y usar un motor de base de datos local (SQLite o MySQL local) — ver [`05-architecture/deployment.md`](../05-architecture/deployment.md).

## Información que haría falta

- Requisitos de software para desarrollo (lenguaje, framework, versión).
- Pasos de instalación y configuración del entorno local.
- Variables de entorno o archivos de configuración necesarios.

Esta información no está documentada en el SRS actual.
