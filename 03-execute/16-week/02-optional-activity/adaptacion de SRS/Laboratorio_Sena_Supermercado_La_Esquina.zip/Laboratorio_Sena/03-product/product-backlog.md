# product-backlog

> Estado: 🔴 No aplica como backlog de producto — información parcialmente disponible en otra sección
> Última actualización: 2026-07-03

## Motivo

El SRS no presenta un backlog de producto en formato de gestión ágil (épicas, historias priorizadas por sprint, estimaciones). Lo más cercano disponible es la **Matriz de Priorización de Requisitos** del SRS (sección 16), que clasifica cada requisito funcional y no funcional por impacto y urgencia.

Esa matriz ya se documenta en [`04-requirements/functional.md`](../04-requirements/functional.md) para evitar duplicar la misma tabla en dos ubicaciones.

## Información que haría falta para un backlog de producto real

- Épicas o iniciativas de negocio.
- Estimaciones de esfuerzo o tamaño.
- Asignación a sprints o iteraciones.
- Estado de avance (por hacer / en progreso / hecho).

Esta información no está documentada en el SRS actual.
