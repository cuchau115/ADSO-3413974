# Architecture Decision Records (ADR)

## Convenciones

- Formato: `ADR-NNN-titulo-corto.md`
- Los ADRs **nunca se eliminan ni se mueven** — permanecen en `records/` con `status: DEPRECATED`
- Cuando una ADR queda obsoleta: cambiar su estado a `DEPRECATED` y agregar al inicio del archivo una línea como `> Reemplazada por: ADR-NNN-nueva.md`
- `99-archive/old-decisions/` se usa solo para documentos de decisión que existían antes de adoptar el formato ADR
- Numeración secuencial desde `ADR-001`

## Template

Usar el archivo [`_template-adr.md`](./_template-adr.md):

```bash
# Reemplazar NNN con el número siguiente y el título con kebab-case
cp 05-architecture/decisions/_template-adr.md \
   05-architecture/decisions/records/ADR-NNN-titulo-corto.md
```

## Registro

| ADR | Título | Estado |
|-----|--------|--------|

## Nota sobre disponibilidad de información

El SRS — Supermercado "La Esquina" no documenta decisiones de arquitectura (no hay alternativas evaluadas, justificaciones técnicas ni trade-offs registrados). Por lo tanto no se crea ningún ADR real: hacerlo implicaría inventar decisiones que el documento fuente no contiene. Para poblar esta carpeta se necesitaría, para cada decisión técnica relevante (ej. motor de base de datos, tipo de aplicación), el contexto evaluado, las alternativas consideradas y la justificación de la elección — información que el SRS no levanta más allá de mencionar las opciones "por ejemplo, SQLite o MySQL local" sin justificar la elección final.
