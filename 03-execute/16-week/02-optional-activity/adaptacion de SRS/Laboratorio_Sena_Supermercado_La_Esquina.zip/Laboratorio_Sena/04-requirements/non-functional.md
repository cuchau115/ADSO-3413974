# non-functional

> Estado: 🟢 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", sección 14 (Requisitos No Funcionales).

Los requisitos no funcionales definen los atributos de calidad que el sistema debe cumplir, independientemente de las funcionalidades específicas.

| ID | Nombre | Descripción | Prioridad |
|---|---|---|---|
| RNF01 | Usabilidad | El sistema debe contar con una interfaz gráfica sencilla e intuitiva, que pueda ser operada sin capacitación técnica avanzada, permitiendo al cajero y al administrador realizar sus tareas con facilidad. | Alta |
| RNF02 | Rendimiento básico | El sistema debe responder a las operaciones más frecuentes (registro de venta, consulta de producto) en un tiempo razonable, sin generar esperas que afecten la atención al cliente. | Media |
| RNF03 | Control de acceso | El sistema debe requerir inicio de sesión con usuario y contraseña para acceder. Existirán dos roles: Administrador (acceso completo) y Cajero (acceso a ventas y caja). Este control no constituye un módulo independiente. | Alta |
| RNF04 | Facilidad de aprendizaje | El sistema debe ser lo suficientemente simple para que cualquier empleado del supermercado pueda aprender a usarlo en un tiempo corto, sin necesidad de conocimientos técnicos especializados. | Alta |
| RNF05 | Confiabilidad básica | El sistema debe guardar la información de ventas e inventario de manera que no se pierda ante un cierre inesperado del programa. | Media |
| RNF06 | Mantenibilidad | El sistema debe estar estructurado de forma que sus módulos sean comprensibles y puedan ser modificados o corregidos sin afectar el funcionamiento general. | Media |

## 14.1 Restricciones del sistema

El SRS ubica las restricciones del sistema (14.1) dentro de la sección "Requisitos No Funcionales". Para evitar duplicar el mismo contenido en dos archivos, se documentan íntegramente en [`01-context/scope.md`](../01-context/scope.md) § Restricciones, ya que ese archivo tiene un campo dedicado exclusivamente a restricciones del proyecto.
