# domain-map

> Estado: 🟢 | Última actualización: 2026-07-03
> Autor: Juan David Gómez Martínez | Equipo: ADSO — Ficha 3413974
> Fuente: SRS — Supermercado "La Esquina", secciones 7.1 y 11.

## Mapa de módulos del sistema

El SRS no define formalmente "bounded contexts" en términos DDD; el nivel de detalle disponible corresponde a los cinco módulos funcionales descritos en el documento:

| Módulo | Descripción según el SRS |
|---|---|
| Ventas | Registro de ventas, cálculo de totales y cambios, generación de comprobantes simples. |
| Inventario | Registro, consulta, actualización y control de productos; alertas de stock bajo. |
| Caja | Cierre de caja diario automatizado, historial de ingresos del día. |
| Reportes | Generación de reportes simples de ventas e inventario por periodos. |
| Proveedores | Registro básico de proveedores y control de pedidos. |

El control de acceso (roles Administrador y Cajero) es transversal a los módulos y no constituye un módulo independiente (ver [`04-requirements/non-functional.md`](../04-requirements/non-functional.md), RNF03).

> El SRS no incluye un diagrama formal de mapa de dominio ni relaciones explícitas entre bounded contexts; esta tabla refleja únicamente la organización modular descrita textualmente en el documento.
