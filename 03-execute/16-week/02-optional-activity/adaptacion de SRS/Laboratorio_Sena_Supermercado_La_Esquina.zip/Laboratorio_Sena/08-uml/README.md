# UML

> Estado: 🔴 Pendiente | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

Repositorio de diagramas UML y arquitectura visual. Todo diagrama debe tener fuente editable y exportación revisable.

## Convenciones

- Fuentes en `diagrams/source/` con extensión `.wsd` o `.puml`
- Exportaciones en `diagrams/exports/` con formato `.svg` preferido
- Nombre de archivo: `<dominio>-<tipo>.<ext>` (ej: `horario-sequence.wsd`)
- Todo diagrama debe registrarse en [diagram-index.md](./diagram-index.md)

## Tipos de diagrama

| Tipo | Archivo fuente |
|------|---------------|
| Casos de uso | `*-use-case.wsd` |
| Clases | `*-class.wsd` |
| Secuencia | `*-sequence.wsd` |
| Actividad | `*-activity.wsd` |
| Estado | `*-state.wsd` |
| Componentes | `*-component.wsd` |
| Despliegue | `*-deployment.wsd` |

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [diagram-index.md](./diagram-index.md) | Índice de fuentes y exportaciones de diagramas | 🔴 No disponible en el SRS |
| [diagrams/source/](./diagrams/source/) | Fuentes editables de diagramas | 🔴 No disponible en el SRS |
| [diagrams/exports/](./diagrams/exports/) | Exportaciones SVG o PNG | 🔴 No disponible en el SRS |

## Nota sobre disponibilidad de información

El documento SRS — Supermercado "La Esquina" es un documento de texto (verificado: no contiene imágenes ni objetos embebidos) y no incluye ningún diagrama UML (casos de uso, clases, secuencia, actividad, estado, componentes o despliegue). Los "Casos de Uso" del SRS (sección 15) están descritos únicamente en formato textual estructurado (actor, flujo, precondiciones), no como diagramas; ese contenido textual se documenta en [`04-requirements/user-stories.md`](../04-requirements/user-stories.md).

Para poblar esta carpeta con diagramas reales haría falta que se produjeran, a partir del SRS, los diagramas UML correspondientes (por ejemplo, un diagrama de casos de uso a partir de CU-01 a CU-04, o un diagrama de clases a partir de las entidades listadas en [`02-domain/entities-and-rules.md`](../02-domain/entities-and-rules.md)) — lo cual constituiría un artefacto nuevo no presente en el SRS, y por tanto queda fuera del alcance de esta reorganización documental.
