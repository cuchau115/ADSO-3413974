# domain-events

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" no contiene una sección ni menciones de eventos de dominio (domain events). El documento describe requisitos funcionales y casos de uso, pero no modela el sistema en términos de eventos generados, publicados o consumidos entre módulos.

## Información que haría falta

Para construir este artefacto sería necesario que el SRS (o un documento de análisis de dominio posterior) especificara, como mínimo:

- Lista de eventos relevantes del negocio (ej. `VentaRegistrada`, `StockBajoDetectado`, `CajaCerrada`, `PedidoCreado`).
- El disparador (trigger) de cada evento.
- Los datos que transporta cada evento.
- Qué módulos u otros procesos reaccionan a cada evento.

Esta información no está documentada en el SRS actual, por lo que este archivo no se completa para evitar introducir contenido no soportado por la fuente.
