# models

> Estado: 🔴 No aplica — información no disponible en el SRS
> Última actualización: 2026-07-03

## Motivo

El SRS — Supermercado "La Esquina" no incluye un modelo de datos (diagrama entidad-relación, esquema de tablas, tipos de datos, claves primarias/foráneas, relaciones o cardinalidades). Únicamente menciona, como interfaz de software, el uso de "un motor de base de datos local (por ejemplo, SQLite o MySQL local)" (sección 12.2), sin detallar su estructura.

Los campos y conceptos que el SRS sí menciona explícitamente se documentan de forma conservadora en [`data-dictionary.md`](./data-dictionary.md), sin construir un modelo formal a partir de ellos.

## Información que haría falta

- Diagrama entidad-relación o esquema lógico/físico.
- Tipos de dato, longitudes y restricciones por campo.
- Claves primarias y foráneas.
- Relaciones y cardinalidades entre entidades (Producto, Venta, Proveedor, Pedido, Cierre de caja, Usuario).

Esta información no está documentada en el SRS actual.
